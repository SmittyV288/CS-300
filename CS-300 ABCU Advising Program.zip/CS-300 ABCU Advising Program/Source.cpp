//============================================================================
// Name        : CS-300 Project 2: Advising Assistance Software
// Author      : Matt Smith
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Allows a user to load a file containing course information,
//				 Allows a user to print a sample schedule,
//				 Allows a user to search and print information
//					for a single course.
//============================================================================

#include <iostream>
#include <time.h>
#include <algorithm>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Course {
	string courseNum; // unique identifier
	string title;
	vector<string> preReqs;
};

// Internal structure for tree node
struct Node {
	Course course;
	Node* left;
	Node* right;

	// default constructor
	Node() {
		left = nullptr;
		right = nullptr;
	}

	// initialize with a course
	Node(Course aCourse) :
		Node() {
		course = aCourse;
	}
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {
private:
	Node* root;

	void addNode(Node* node, Course course);
	void inOrder(Node* node);
	Node* removeNode(Node* node, string courseNum);

public:
	BinarySearchTree();
	virtual ~BinarySearchTree();
	void InOrder();
	void Insert(Course course);
	void Remove(string courseNum);
	Course Search(string courseNum);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
	// Set root equal to nullptr
	root = nullptr;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
	// while root does not equal nullptr, call Remove function with root bidId
	while (root != nullptr) {
		Remove(root->course.courseNum);
	}
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
	// call inOrder function with root
	inOrder(root);
}

/**
 * Remove a bid
 */
Node* BinarySearchTree::removeNode(Node* node, string courseNum) {
	// if node is equal to nullptr, return node
	if (node == nullptr) {
		return node;
	}

	else if (courseNum.compare(node->course.courseNum) < 0) { // If bidId is less than node bidId
		node->left = removeNode(node->left, courseNum); // Call removeNode function with left node and bidId, assign to left node
	}

	else if (courseNum.compare(node->course.courseNum) > 0) { // If bidId is greater than node bidId
		node->right = removeNode(node->right, courseNum); // Call removeNode function with right node and bidId, assign to right node
	}
	else {
		if (node->left == nullptr && node->right == nullptr) { // If left and right node are equal to nullptr
			delete node; // Delete node
			node = nullptr; // Set node equal to nullptr
		}
		else if (node->left != nullptr && node->right == nullptr) { // If left node does not equal nullptr and right node does
			Node* succNode = node; // Set new successor node equal to node
			node = node->left; // Set node equal to left node
			delete succNode; // Delete successor node
			succNode = nullptr; // Set successor node equal to nullptr
		}
		else if (node->left == nullptr && node->right != nullptr) { // If left node equal nullptr and right node does not
			Node* succNode = node; // Set new successor node equal to node
			node = node->right; // Set node equal to right node
			delete succNode; // Delete successor node
			succNode = nullptr; // Set successor node equal to nullptr
		}
		else {
			Node* succNode = node->right; // Set successor node equal to right node
			while (succNode->left != nullptr) { // While node left of successor node does not equal nullptr
				succNode = succNode->left; // Set successor node equal to left node
			}
			node->course = succNode->course; // Set node bid equal to successor node bid
			node->right = removeNode(node->right, succNode->course.courseNum); // Call removeNode function with right node and successor node bidId, Set right node equal to return
		}
	}
	return node;
}

/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Course course) {
	// FIXME (5) Implement inserting a bid into the tree
	// if root equarl to null ptr
	
	// root is equal to new node bid
  // else
	// add Node root and bid

	if (root == nullptr) { // Check if root is equal to nullprt
		root = new Node(course); // Assign root equal to new Node with bid
	}
	else {
		addNode(root, course); // Call function to add node with root and bid
	}
}

/**
 * Remove a bid
 */
void BinarySearchTree::Remove(string bidId) {
	
	// Call removeNode function with root and bidId
	this->removeNode(root, bidId); // 
}

/**
 * Search for a bid
 */
Course BinarySearchTree::Search(string courseNum) {
	
	// Create current node and set equal to root
	Node* cur = root;

	// Loop while current node does not equal nullptr
	while (cur != nullptr) {

		// If current node bidId matches bidId, return current node bid
		if (cur->course.courseNum.compare(courseNum) == 0) {
			return cur->course;
		}

		// If bidId is less than current node bidId, set current node equal to left node
		else if (courseNum.compare(cur->course.courseNum) < 0) {
			cur = cur->left;
		}
		else {
			cur = cur->right; // Set current node equal to right node
		}
	}
	Course course; // Create variable to hold bid
	return course; // Return bid
}

/**
 * Add a bid to some node (recursive)
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 */
void BinarySearchTree::addNode(Node* node, Course course) {

	// If node bidId is greater than bidId
	if (node->course.courseNum.compare(course.courseNum) > 0) {
		// If left node is equal to nullptr, set left node equal to new Node bid
		if (node->left == nullptr) {
			node->left = new Node(course);
		}
		// Call addNode function with left node and bid
		else {
			this->addNode(node->left, course);
		}
	}
	// If node bidId is less than bidId
	else {
		// If right node is equal to nullptr, set right node equal to new Node bid
		if (node->right == nullptr){
			node->right = new Node(course);
		}
		// Call addNode function with right node and bid
		else {
			this->addNode(node->right, course);
		}
	}
}
void BinarySearchTree::inOrder(Node* node) {
	// FixMe (9): Pre order root
	//if node is not equal to null ptr
	//InOrder not left
	//output bidID, title, amount, fund
	//InOder right

	// If node does not equal nullptr
	if (node != nullptr) {
		inOrder(node->left); // Call inOrder function with left node
		
		// Put out node bid information
		cout << node->course.courseNum << ": " << node->course.title;
		for (string preReq : node->course.preReqs) {
			cout << " | " << preReq;
		}
		cout << endl;
		// Call inOrder function with right node
		inOrder(node->right);
	}
}


//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the course information to the console (std::out)
 *
 * @param course struct containing the course info
 */
void displayCourse(Course course) {
	cout << course.courseNum << ": " << course.title << endl;
	if (course.preReqs.size() > 0) {
		cout << "Prerequisites: ";
		for (string pre : course.preReqs) {
			cout << pre << " | ";
		}
	}
	cout << endl << endl;
	return;
}

/**
 * Load a file containing courses into a container
 *
 * @param  the path to the file to load
 * @return a container holding all the courses read
 */
void loadCourses(string csvPath, BinarySearchTree* bst) {

	cout << "Loading file " << csvPath << endl; // Prints the file to be loaded based on user inpiut
	
	// Define variables 
	ifstream inFS;
	vector<Course> randomCourses;
	char delimiter = ',';
	string line;

	inFS.open(csvPath); // Opens file

	// Checks if file is open, tells the user if file cant be opened
	if (!inFS.is_open()) {
		cout << "Unable to open " << csvPath << endl;
		return;
	}

	// Gets each line of file while there are lines
	while (getline(inFS, line)) {

		// Define variables
		stringstream ss(line);
		Course course;

		
		if (getline(ss, course.courseNum, delimiter) && getline(ss, course.title, delimiter)) { // Get course number and course title from line
			
			// Define variable for prerequisite 
			string prereq;

			// Get prerequisites from line if they exist
			while (getline(ss, prereq, delimiter)) {
				course.preReqs.push_back(prereq);
			}
		}
		randomCourses.push_back(course); // Add course to vector
	}

	random_shuffle(randomCourses.begin(), randomCourses.end()); // Shuffle vector to make it unsorted

	// Adds each item from vector to tree
	for (unsigned int i = 0; i < randomCourses.size(); i++) {
		bst->Insert(randomCourses.at(i));
	}

	// Checks each course in randomCourses to determine if prerequiste exists as course.
    for (const Course course : randomCourses) {
        for (const string prereq : course.preReqs) {
            if (bst->Search(prereq).courseNum.empty()) {
				bst->Remove(course.courseNum);
                cout << "Course " << course.courseNum << " has been removed because prerequisite "
					<< prereq << " does not exist as a course." << endl;
            }
        }
    }

	cout << "File loaded successfully!" << endl << endl;
}


/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
	str.erase(remove(str.begin(), str.end(), ch), str.end());
	return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {
	// process command line arguments
	string csvPath, courseKey;

	// Define a binary search tree to hold all bids
	BinarySearchTree* bst;
	bst = new BinarySearchTree();
	Course course;

	int choice = 0;
	bool dataLoaded = false;
	cout << "Welcome to the course planner!" << endl << endl;
	while (choice != 4) {
		cout << "Menu:" << endl;
		cout << "  1. Load Data Structure" << endl;
		cout << "  2. Print Course List" << endl;
		cout << "  3. Print Course" << endl;
		cout << "  4. Exit" << endl;
		cout << "Enter choice: ";
		
		cin >> choice;

		cin.clear();
		// discards the input buffer
		cin.ignore(numeric_limits<streamsize>::max(), '\n');


		switch (choice) {
		case 1:

			cout << "Please enter file name (Example: courses.txt): " << endl;
			getline(cin, csvPath);
		
			// Call function to load courses
			loadCourses(csvPath, bst);
			dataLoaded = true;
			break;

		case 2:
			// If data was loaded
			if (dataLoaded){
				cout << "Here is the sample schedule:" << endl << endl;
				bst->InOrder(); // Print courses in order
				cout << endl;
			}
			else {
				cout << "Please load courses before selecting this option" << endl << endl;
			}

			break;

		case 3:

			// If data was loaded
			if (dataLoaded) {
				cout << "What course do you want to know about?: ";
				getline(cin, courseKey); // Get input from user

				// Capitalize each letter from user input
				for (auto& c : courseKey) {
					c = toupper(c);
				}
				course = bst->Search(courseKey); // Call search function with user input and assign to course


				if (!course.courseNum.empty()) {
					displayCourse(course); // Display course information if not empty
				}
				else {
					cout << "Course ID " << courseKey << " not found." << endl << endl;
				}
			}
			else {
				cout << "Please load courses before selecting this option" << endl << endl;
			}
			

			break;

		case 4:
			cout << "Thank you for using the course planner!" << endl;
			break;

		default:
			cout << to_string(choice) + " is not a valid option." << endl << endl;
			break;

		}
		

	}

	return 0;
}